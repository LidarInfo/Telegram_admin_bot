const config = {
    admin: 1141146295,
    bot: {
        token: '1111111111:AAE1qotUY3qIdkGizRiaBP8xnE6oRrEDkPA',
        username: '@юз_бота'
    },
    db: {
        url: 'mongodb://127.0.0.1:27017/test'
    },
}

export default config;
